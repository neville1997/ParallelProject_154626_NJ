package com.cg.dao;

import java.util.*;

import com.cg.dto.*;

/**
 * 
 * This is a CarDAO class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public interface WalletDAO 
{
    public List<Customer> findAll(); 
    public Customer findById(int id);
    public void create(Customer customer);
    public void update(Customer customer);
    public void delete(String[] ids);
}