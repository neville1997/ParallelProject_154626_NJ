package com.cg.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import com.cg.dao.WalletDAO;
import com.cg.dto.Customer;

/**
 * 
 * This is a JPACarDAO class
 * 
 * @see java.lang.Object
 * @author Neville
 * 
 *
 */

@Repository
public class JPAWalletDAO implements WalletDAO {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Customer> findAll() {
		try {
			Query query = entityManager.createQuery("select customer from Customer customer");
			return query.getResultList();
		} finally {
			entityManager.close();
		}
	}

	@Override
	public Customer findById(int id) {
		try {
			Query query = 
				entityManager.createQuery("select customer from Customer customer where ID = ?");
			query.setParameter(1, id);
			return (Customer) query.getSingleResult();
		} finally {
			entityManager.close();
		}
	}

	@Override
	public void create(Customer customer) {
		try {
			System.out.println("Inside create car");
			entityManager.persist(customer);
			System.out.println("afermerge");
	      	System.out.println("Car added succesfully!");
			System.out.println(customer.getId());
			return;
		} finally {
			entityManager.close();
		}
	}

	@Override
	public void update(Customer customer) {
		Query query = entityManager.createQuery("update customersnew set mobileNo=?,name=?,balance=? where id=?");
		query.setParameter(1, customer.getMobileNo());
		query.setParameter(2, customer.getName());
		query.setParameter(3, customer.getBalance());
		query.setParameter(4, customer.getId());
		query.executeUpdate();
	}

	@Override
	public void delete(String[] ids) {
		System.out.println("In delete");
		Query query = entityManager.createQuery("delete from customersnew where id=?");
		for(String id:ids) {
			query.setParameter(1, id);
			query.executeUpdate();
		}

	}

}
