package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "History")
public class History {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="ID")
	private int id;
	
	@Column(name="time")
	String time;
	
	@Column(name="histMobileNo")
	String histMobileNo;
	
	@Column(name="operation")
	int operation;
	
	@Column(name="histAmount")
	float histAmount;
	
	// Default constructor
	public History() {

	}
	
	// Parameterized Constructor
	public History(String histmobileno, int operation, float histamount, String time) {
		this.histMobileNo = histmobileno;
		this.operation = operation;
		this.histAmount = histamount;
		this.time = time;
	}
	
	// To String method for Customer object
	@Override
	public String toString() {
		return "\n" + "Number=" + histMobileNo + ", Operation Number=" + operation
				 + ", Transaction Amount= " + histAmount;
	}
	
	// Getters and Setters 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHistmobileno() {
		return histMobileNo;
	}
	public void setHistmobileno(String histmobileno) {
		this.histMobileNo = histmobileno;
	}
	public int getOperation() {
		return operation;
	}
	public void setOperation(int operation) {
		this.operation = operation;
	}
	public float getHistamount() {
		return histAmount;
	}
	public void setHistamount(float histamount) {
		this.histAmount = histamount;
	}
}
