package com.cg.service;

public class ServiceDAOImpl implements ServiceDAO {

}
