package com.cg.service;

public interface ServiceDAO {

}
